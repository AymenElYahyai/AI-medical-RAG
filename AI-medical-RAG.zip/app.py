import os
import subprocess
from fastapi import FastAPI, UploadFile
from fastapi.middleware.cors import CORSMiddleware
import fitz  # PyMuPDF
import faiss
import numpy as np
import pytesseract
from PIL import Image
import gradio as gr
from sentence_transformers import SentenceTransformer
import requests

# Initialisation
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_FOLDER = "./uploads/"
INDEX_PATH = "./index/medical_faiss_index"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(os.path.dirname(INDEX_PATH), exist_ok=True)

# Modèle et index FAISS
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
model = SentenceTransformer(EMBEDDING_MODEL)
documents = []

if os.path.exists(INDEX_PATH):
    index = faiss.read_index(INDEX_PATH)
    print("Index FAISS chargé avec succès.")
else:
    index = faiss.IndexFlatL2(model.get_sentence_embedding_dimension())
    print("Nouvel index FAISS créé.")

# Fonction d'extraction de texte
def extract_text_from_pdf(file_content: bytes):
    pdf = fitz.open(stream=file_content, filetype="pdf")
    paragraphs = []
    for page in pdf:
        text = page.get_text()
        if text.strip():
            paragraphs.extend([p.strip() for p in text.split("\n\n") if p.strip()])
    return paragraphs



# Ajouter des documents
def add_medical_reference(file_path):
    with open(file_path, "rb") as f:
        file_content = f.read()
    paragraphs = extract_text_from_pdf(file_content)
    embeddings = model.encode(paragraphs)
    index.add(np.array(embeddings, dtype="float32"))
    documents.extend(paragraphs)
    faiss.write_index(index, INDEX_PATH)
    return "Référence médicale ajoutée avec succès."

# Analyser un fichier
def analyze_blood_test(file_path):
    try:
       
        if file_path.endswith(".pdf"):
            with open(file_path, "rb") as f:
                file_content = f.read()
            paragraphs = extract_text_from_pdf(file_content)
        else:
            return "Format non supporté. Utilisez un PDF."

        responses = []
        for paragraph in paragraphs:
            relevant_docs = search_faiss(paragraph, k=3)
            context = "\n".join(relevant_docs)
            enriched_prompt = f"Voici un segment d'analyse :\n{paragraph}\n\nContexte pertinent :\n{context}"
            gemini_response = call_gemini_api(enriched_prompt)
            responses.append(f"Réponse générée :\n{gemini_response}\n")

        return "\n\n".join(responses)
    except Exception as e:
        return f"Erreur : {str(e)}"

# Recherche FAISS
def search_faiss(query, k=5):
    query_embedding = model.encode([query])
    distances, indices = index.search(np.array(query_embedding, dtype="float32"), k)
    return [documents[i] for i in indices[0] if i < len(documents)]

# Appel API Gemini
def call_gemini_api(prompt):
    GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent"
    GEMINI_API_KEY = "AIzaSyALDnGnCP4AuC3uX5dXcYugrfO89clRG9o"
    headers = {"Content-Type": "application/json"}
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(f"{GEMINI_API_URL}?key={GEMINI_API_KEY}", json=payload, headers=headers)
        return response.json().get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "Pas de réponse.")
    except Exception as e:
        return f"Erreur API : {str(e)}"

# Interface Gradio
with gr.Blocks() as demo:
    gr.Markdown("## Analyse Médicale avec RAG et Gemini")

    with gr.Tab("Ajouter Références Médicales"):
        ref_file = gr.File(label="Téléchargez un fichier PDF de référence médicale")
        ref_output = gr.Textbox(label="Résultat")
        ref_button = gr.Button("Ajouter")
        ref_button.click(add_medical_reference, inputs=ref_file, outputs=ref_output)

    with gr.Tab("Analyser un Résultat d'Analyse"):
        test_file = gr.File(label="Téléchargez un fichier PDF")
        analysis_output = gr.Textbox(label="Résultat")
        analyze_button = gr.Button("Analyser")
        analyze_button.click(analyze_blood_test, inputs=test_file, outputs=analysis_output)

demo.launch()